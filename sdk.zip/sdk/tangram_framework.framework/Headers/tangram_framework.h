//
//  tangram_framework.h
//  tangram_framework
//
//  Created by Matt Smollinger on 7/8/16.
//
//

#import <UIKit/UIKit.h>

//! Project version number for tangram_framework.
FOUNDATION_EXPORT double tangram_frameworkVersionNumber;

//! Project version string for tangram_framework.
FOUNDATION_EXPORT const unsigned char tangram_frameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <tangram_framework/PublicHeader.h>

#import <tangram_framework/TGMapViewController.h>
