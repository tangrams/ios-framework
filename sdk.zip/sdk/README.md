# Tangram-es iOS Binary Framework

This repository hosts the binary artifacts from the Tangram iOS builds. Currently these build are device-only as we hone our build process over in https://github.com/tangrams/tangram-es. In short order we plan to support both the simulator and device builds from a single framework file.

In the mean time, feel free to test this out and give us your feedback either here or in the main tangram-es repository.
